enum Result {
	LOW, SAME, HIGH
}
