class BoardTest1 {
	public static void main(String[] args){
		Board board = new Board();
		board.put(0, 0);
		board.put(8, 1);
		board.show();
	}
}
