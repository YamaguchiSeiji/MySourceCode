class NegativeArraySizeExpetionTest{
	public static void main(String[] args) {
    	System.out.println("NegativeArraySizeExceptionを発生させます.");
		int n = -1;
		int array[] = new int[n];
	}
}
