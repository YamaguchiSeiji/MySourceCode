class InvailSizeException extends Exception {
	InvailSizeException(String msg){
		super(msg);
	}
}
