class ArrayIndexOutOfBoundsExceptionTest {
	public static void main(String[] args){
		System.out.println("ArrayIndexOutOfBoundsExpetionを発生させます.");
		int n[] = {1, 2, 3};
		System.out.println(n[3]);
	}
}
