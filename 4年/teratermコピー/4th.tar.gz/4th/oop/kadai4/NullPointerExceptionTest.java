class NullPointerExceptionTest {
	public static void main(String[] args) {
    	System.out.println("NullPointerExceptionを発生させます.");
		String s = null;
		System.out.println(s.length());
  	}
}
