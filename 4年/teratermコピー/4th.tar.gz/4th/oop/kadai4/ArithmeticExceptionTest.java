class ArithmeticExceptionTest {
	public static void main(String[] args){
		System.out.println("ArithmeticExpetionを発生させます.");
		System.out.println(2 / 0);
		System.out.println("Hello");
	}
}
