class CardTest1 {
	public static void main(String[] args){
		for(int i = 0; i < 10; i++){
			Card c = new Card();
			System.out.println(c);
		}
	}
}
