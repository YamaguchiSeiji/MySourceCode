enum Type{
	FIRE,
	WATER,
	GRASS
}
