class ClockTest{
	public static void main(String[] args){
		Clock clk2 = new Clock(false);
		clk2.show();

		Clock clk1 = new Clock(true);
		clk1.show();
	}
}
