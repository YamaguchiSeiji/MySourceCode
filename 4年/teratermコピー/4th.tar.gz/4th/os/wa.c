#include <stdio.h>
int main(){
	int a, b;
	int ans;

	scanf("%d", &a);
	scanf("%d", &b);

	ans = a + b;

	printf("%d\n", ans);

	return 0;
}
