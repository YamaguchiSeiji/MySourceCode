#ifndef FUNC
#define FUNC

double mysin(double);

#endif
