#include <stdio.h>
#include <limits.h>

int main(){
	int n[10];
	puts("この処理系における型のサイズ:");
	printf("n: %zuバイト\n",sizeof(n));

	return 0;
}
