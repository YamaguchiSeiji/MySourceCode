#include <stdio.h>
int main(){
	char c=127;
	printf("%d\n",c);
	c++;
	printf("%d\n",c);

	return 0;
}
