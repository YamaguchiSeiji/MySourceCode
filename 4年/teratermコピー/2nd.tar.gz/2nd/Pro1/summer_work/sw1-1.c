#include <stdio.h>
int main(){
	int d,l;
	scanf("%d %d",&d,&l);
	printf("%d\n",d/l+d%l);
	return 0;
}
