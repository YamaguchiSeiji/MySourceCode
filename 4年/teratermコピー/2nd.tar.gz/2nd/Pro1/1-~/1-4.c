#include <stdio.h>
int main(){
	printf("%d\n",12+34*5);
	return 0;
}
