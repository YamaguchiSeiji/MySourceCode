#include <stdio.h>
int main(){
	int no;
	
	printf("整数を入力してください:");
	scanf("%d",&no);
	
	printf("その数の5倍は%dです。\n",no*5);
	
	return 0;

}
