#include <stdio.h>
int main(){
	int a,b;
	
	printf("整数aを入力してください：");
	scanf("%d",&a);
	printf("整数bを入力してください：");
	scanf("%d",&b);

	printf("a+b:%d\n",a+b);
	printf("a-b:%d\n",a-b);
	printf("a*b:%d\n",a*b);
	printf("a/b:%d\n",a/b);
	printf("a%%b:%d\n",a%b);
	
	return 0;
}
