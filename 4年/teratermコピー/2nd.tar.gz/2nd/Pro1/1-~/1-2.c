#include <stdio.h>
int main(){
	printf("Hello! My name is Seiji Yamaguchi.\nMy hobby is playing badminton.\n");
	return 0;
}
