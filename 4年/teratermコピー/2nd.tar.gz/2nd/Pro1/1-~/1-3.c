#include <stdio.h>
int main(){
	puts("Hello! My name is Seiji Yamaguchi.\nMy hobby is playing badminton.");
	return 0;
}
