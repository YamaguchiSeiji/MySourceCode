#include <stdio.h>
int main(){
	int a;
	printf("整数を入力してください：");
	scanf("%d",&a);

	printf("%05d\n",a);

	return 0;
}
