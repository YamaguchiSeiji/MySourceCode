#include <stdio.h>
int main(){
	int num=0;
	while(1){
		printf("%d\n",num);
		num++;
	}
	return 0;
}
