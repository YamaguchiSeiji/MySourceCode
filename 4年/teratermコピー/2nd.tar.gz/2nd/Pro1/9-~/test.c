#include <stdio.h>
int main(){
	char c[1024]={};
	
}
