#include <stdio.h>
int main(){
	printf("printf(\"%%d\\n\", x);\n");
}

