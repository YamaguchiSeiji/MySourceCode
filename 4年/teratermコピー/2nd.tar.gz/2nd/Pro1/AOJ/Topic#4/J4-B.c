#include <stdio.h>
int main(){
    double r;
    scanf("%lf",&r);
    printf("%f %f",r*r*3.141592653589,2*r*3.141592653589);
    return 0;
}
