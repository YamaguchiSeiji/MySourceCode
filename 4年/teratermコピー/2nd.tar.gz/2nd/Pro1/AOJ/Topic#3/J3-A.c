#include <stdio.h>
int main(){
    for(int i=0;i<1000;i++){
        printf("Hello World\n");
    }
    return 0;
}
